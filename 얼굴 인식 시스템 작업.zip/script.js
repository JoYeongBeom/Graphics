// 스크립트 코드
const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const registerButton = document.getElementById('registerButton');
const attendanceButton = document.getElementById('attendanceButton');
const exportButton = document.getElementById('exportButton');

let labeledDescriptors = [];

Promise.all([
  faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
  faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
  faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
  faceapi.nets.faceExpressionNet.loadFromUri('/models')
]).then(startVideo)

// 웹캠 스트림 가져오기
function startVideo() {
navigator.mediaDevices.getUserMedia({ video: true })
  .then((stream) => {
    video.srcObject = stream;
  })
  .catch((error) => {
    console.error('Error accessing webcam:', error);
  });
}

// 얼굴 등록 버튼 클릭 이벤트 핸들러
registerButton.addEventListener('click', () => {
  // 웹캠에서 현재 화면 캡처
  const context = canvas.getContext('2d');
  context.drawImage(video, 0, 0, canvas.width, canvas.height);

  // 얼굴 인식 및 등록
  faceapi.detectSingleFace(canvas)
    .withFaceLandmarks()
    .withFaceDescriptor()
    .then((face) => {
      if (face) {
        const descriptor = face.descriptor;
        const name = prompt('이름을 입력하세요:');

        labeledDescriptors.push(new faceapi.LabeledFaceDescriptors(name, [descriptor]));
        console.log('얼굴이 등록되었습니다:', name);
      } else {
        console.log('얼굴을 인식할 수 없습니다.');
      }
    })
    .catch((error) => {
      console.error('Error detecting face:', error);
    });
});

// 출석 버튼 클릭 이벤트 핸들러
attendanceButton.addEventListener('click', () => {
  // 웹캠에서 현재 화면 캡처
  const context = canvas.getContext('2d');
  context.drawImage(video, 0, 0, canvas.width, canvas.height);

  // 얼굴 인식 및 출석 확인
  faceapi.detectSingleFace(canvas)
    .withFaceLandmarks()
    .withFaceDescriptor()
    .then((face) => {
      if (face) {
        const queryDescriptor = face.descriptor;

        for (const labeledDescriptor of labeledDescriptors) {
          const faceMatcher = new faceapi.FaceMatcher(labeledDescriptor.descriptors);
          const bestMatch = faceMatcher.findBestMatch(queryDescriptor);

          if (bestMatch.label !== 'unknown') {
            console.log('출석 확인:', bestMatch.label);
            return;
          }
        }

        console.log('출석 확인되지 않음.');
      } else {
        console.log('얼굴을 인식할 수 없습니다.');
      }
    })
    .catch((error) => {
      console.error('Error detecting face:', error);
    });
});

// 출석부 출력 버튼 클릭 이벤트 핸들러
exportButton.addEventListener('click', () => {
  const worksheet = XLSX.utils.aoa_to_sheet([['이름', '출석 여부']]);
  let rowIndex = 1;

  for (const labeledDescriptor of labeledDescriptors) {
    XLSX.utils.sheet_add_aoa(worksheet, [[labeledDescriptor.label, '출석']], { origin: `A${rowIndex}` });
    rowIndex++;
  }

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append(workbook, worksheet, '출석부.xlsx');

  // 엑셀 파일 다운로드
  const workbookBlob = new Blob([s2ab(XLSX.write(workbook, { bookType: 'xlsx', type: 'binary' }))], {
    type: 'application/octet-stream'
  });
  saveAs(workbookBlob, '출석부.xlsx');
});

// ArrayBuffer 변환 함수
function s2ab(s) {
  const buf = new ArrayBuffer(s.length);
  const view = new Uint8Array(buf);
  for (let i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xff;
  return buf;
}
